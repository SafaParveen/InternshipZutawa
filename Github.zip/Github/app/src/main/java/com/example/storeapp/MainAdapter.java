package com.example.storeapp;

import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;

import java.util.ArrayList;

public class MainAdapter extends RecyclerView.Adapter<MainAdapter.ViewHolder> {




    private ArrayList<Dataum>dataArrayList;
    private Context context;


    public MainAdapter(Context context,ArrayList<Dataum>dataArrayList)
    {
        this.context=context;
        this.dataArrayList=dataArrayList;

    }


    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {



        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.list_row_main,parent,false);

        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        Dataum data = dataArrayList.get(position);
        Glide.with(context).load(data.getAvatar()).diskCacheStrategy(DiskCacheStrategy.ALL).into(holder.imageView);
        holder.textView.setText(data.getName());
        holder.textView2.setText(Integer.toString(data.getId()));

        holder.contact.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String url = data.getUrl();

                //Toast.makeText(context, url, Toast.LENGTH_SHORT).show();







                Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                context.startActivity(browserIntent);






            }
        });



    }



    @Override
    public int getItemCount() {
        return dataArrayList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {


        ImageView imageView;
        CardView contact;
         TextView textView,textView2;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            contact=itemView.findViewById(R.id.contact);
            imageView=itemView.findViewById(R.id.imae_view);
            textView=itemView.findViewById(R.id.text_view);
            textView2=itemView.findViewById(R.id.text_view2);

        }
    }
}
